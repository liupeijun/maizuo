<template>
  <div>
    <div>大轮播</div>
    <!-- 路由容器 -->
    <router-view></router-view>
  </div>
</template>
