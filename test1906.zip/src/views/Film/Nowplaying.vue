<template>
  <div>
     nowplaying
  </div>
</template>
