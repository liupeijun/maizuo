<template>
  <div>
    hello vue -{{myname}}
    <input type="text" v-model="mytext"/>
    <button @click="handleClick()">click</button>
    <ul>
      <li v-for="data in datalist" :key="data">
        {{data}}
      </li>
    </ul>
    <child1 :myword="mytext">
      <div>插槽技术</div>
    </child1>
  </div>
</template>
<script>
// 导入 import from
// 导出 export default
// import Vue from 'vue'
import child1 from './components/Child1'
// Vue.component('child1', child1)

export default {
  data () {
    return {
      myname: 'app根组件',
      mytext: '',
      datalist: []
    }
  },
  computed: {

  },
  components: {
    child1
  },
  methods: {
    handleClick () {
      console.log(this.mytext)
      this.datalist.push(this.mytext)
    }
  }
}
</script>
<style lang="scss">
  *{
    margin:0;
    padding:0;
  }

  html,body{
    height: 100%;
  }

  ul {
    li{
      list-style:none;
      background: blue;
    }
  }
</style>
